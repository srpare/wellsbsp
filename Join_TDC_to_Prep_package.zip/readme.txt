Readme:

The SAS tables and program attached are prototypes to demonstrate the process and tables that looks similar to WF prep, TDC output, and look up to obtain the 
right flex information. This code takes alert results, and uses a look up table to join back to the prep tables to get the flex field inputs and get the fields that are on the 
final CBSP files such as cust_num, emp_id..etc

Please see the comments below before running the programs.

o	Unzip the data files. Put tdc and prep tables in Teradata DB or unix folder or local folder.
o       Put prod_alerts_ref_full.sas table in indata library or Teradata library.
o	Please UPDATE and CHECK all libnames references in the post_alert_join.sas program.
o	CHANGE the hard coded libnames before running the post_alert_join.sas program.
o	Libname indata can be any location that can be accessed to read reference table.
o	Note that this prototype doesn�t cover the NAO lagged table and some prep table fields are not exactly as they will be with the real data because
	we created mock data without much insight into the real data.
o	Note that we are not doing SQL pass through but rather pulling everything into SAS, performing all the steps and then would need read back into a DB
o	Macros referenced in code (%read_flex_fields, %flex_fields, %add_co and %add_ff) may be modified and edited separately as things change. 
	They can also be added to macro catalog and called in the program.
o	Note that this is strictly a prototype to exemplify SAS�s understanding of what needs to happen and that we are just outputting work tables, etc.
o	The idea is to have a process that would work for ALL strategies/scenarios.
o	Note that cust_num, acct_num, emp_id, co_id, branch_au, ptype, pcode are in all relevant prep tables by design because these are fields in cbsp, prod_alerts and
	prod_cons_alerts files for all strategies whether they are null or populated.
